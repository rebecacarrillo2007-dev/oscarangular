<script setup>
import { isAuthenticated, logout } from '../auth'
import { useRouter } from 'vue-router'

const router = useRouter()

const handleLogout = () => {
  logout()
  router.push('/login')
}
</script>

<template>
  <nav class="navbar">
    <h1 class="logo">Mi App</h1>
    <div class="links">
      <router-link to="/">Home</router-link>
      <router-link v-if="!isAuthenticated" to="/login">Login</router-link>

      <template v-else>
        <router-link to="/clientes">Clientes</router-link>
        <router-link to="/ventas">Ventas</router-link>
        <router-link to="/contacto">Contacto</router-link>
        <button @click="handleLogout" class="logout-btn">Cerrar sesión</button>
      </template>
    </div>
  </nav>
</template>

<style scoped>
.navbar {
  background: #1976d2;
  color: white;
  padding: 10px 20px;
  display: flex;
  justify-content: space-between;
  align-items: center;
}
.logo {
  font-size: 20px;
  font-weight: bold;
}
.links {
  display: flex;
  gap: 15px;
  align-items: center;
}
a {
  color: white;
  text-decoration: none;
  font-weight: 500;
}
a:hover {
  text-decoration: underline;
}
.logout-btn {
  background: #e53935;
  border: none;
  padding: 6px 12px;
  color: white;
  border-radius: 4px;
  cursor: pointer;
}
.logout-btn:hover {
  background: #c62828;
}
</style>
