import { createRouter, createWebHistory } from 'vue-router'

import Home from '../views/Home.vue'
import Login from '../views/Login.vue'
import Ventas from '../views/Ventas.vue'
import Clientes from '../views/Clientes.vue'
import Contacto from '../views/Contacto.vue'

const requireAuth = (to, from, next) => {
  if (localStorage.getItem('auth') === 'true') {
    next()
  } else {
    next('/login')
  }
}

const router = createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', name: 'home', component: Home },
    { path: '/login', name: 'login', component: Login },
    { path: '/ventas', name: 'ventas', component: Ventas, beforeEnter: requireAuth },
    { path: '/clientes', name: 'clientes', component: Clientes, beforeEnter: requireAuth },
    { path: '/contacto', name: 'contacto', component: Contacto, beforeEnter: requireAuth }
  ]
})

export default router
