import { ref } from 'vue'

// Estado global de autenticación
export const isAuthenticated = ref(false)

export function login(user, pass) {
  if (user === 'admin' && pass === 'admin123') {
    isAuthenticated.value = true
    localStorage.setItem('auth', 'true')
    return true
  }
  return false
}

export function logout() {
  isAuthenticated.value = false
  localStorage.removeItem('auth')
}

// Inicializar desde localStorage
if (localStorage.getItem('auth') === 'true') {
  isAuthenticated.value = true
}
