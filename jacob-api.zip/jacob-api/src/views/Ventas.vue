<script setup>
import { ref, onMounted } from 'vue'

const ventas = ref([])
const cargando = ref(true)
const errorMsg = ref('')

onMounted(async () => {
  try {
    const res = await fetch('https://68d3e670214be68f8c67a728.mockapi.io/venta')
    if (!res.ok) {
      throw new Error(`HTTP error! status: ${res.status}`)
    }
    const data = await res.json()
    console.log('Datos de ventas:', data)
    ventas.value = data
  } catch (err) {
    console.error('Error cargando ventas:', err)
    errorMsg.value = 'No se pudo cargar las ventas'
  } finally {
    cargando.value = false
  }
})
</script>

<template>
  <div>
    <h1>Ventas</h1>

    <div v-if="cargando">Cargando ventas...</div>
    <div v-if="errorMsg">{{ errorMsg }}</div>

    <ul v-if="ventas.length > 0">
      <li v-for="venta in ventas" :key="venta.id" style="margin-bottom: 1rem;">
        <!-- Verificamos que los campos existan antes de mostrarlos -->
        <div v-if="venta.imagen">
          <img :src="venta.imagen" alt="producto" width="80" height="80" />
        </div>
        <strong>{{ venta.producto ?? venta.name ?? 'Producto sin nombre' }}</strong> -
        ${{ venta.precio ?? venta.price ?? '0' }}
      </li>
    </ul>

    <div v-else-if="!cargando">No hay ventas para mostrar.</div>
  </div>
</template>

<style scoped>
/* Un pequeño estilo para separar las ventas */
li {
  list-style: none;
}
</style>
