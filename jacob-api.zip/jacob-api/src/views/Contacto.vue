<script setup>
import { ref } from 'vue'

const nombre = ref('')
const correo = ref('')
const mensaje = ref('')

const enviar = () => {
  console.log('Mensaje enviado:', {
    nombre: nombre.value,
    correo: correo.value,
    mensaje: mensaje.value
  })
  alert('Formulario enviado ✅')
  nombre.value = ''
  correo.value = ''
  mensaje.value = ''
}
</script>

<template>
  <div>
    <h1>Contacto</h1>
    <form @submit.prevent="enviar">
      <input v-model="nombre" placeholder="Tu nombre" />
      <input v-model="correo" placeholder="Tu correo" />
      <textarea v-model="mensaje" placeholder="Mensaje"></textarea>
      <button type="submit">Enviar</button>
    </form>
  </div>
</template>
