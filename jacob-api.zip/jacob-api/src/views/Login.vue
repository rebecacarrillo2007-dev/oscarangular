<script setup>
import { ref } from 'vue'
import { login } from '../auth'
import { useRouter } from 'vue-router'

const username = ref('')
const password = ref('')
const errorMsg = ref('')
const router = useRouter()

const handleLogin = () => {
  if (login(username.value, password.value)) {
    router.push('/clientes')
  } else {
    errorMsg.value = 'Usuario o contraseña incorrectos'
  }
}
</script>

<template>
  <div class="login-container">
    <div class="login-card">
      <h1>Login</h1>
      <input v-model="username" placeholder="Usuario" />
      <input v-model="password" type="password" placeholder="Contraseña" />
      <button @click="handleLogin">Ingresar</button>
      <p v-if="errorMsg" class="error">{{ errorMsg }}</p>
    </div>
  </div>
</template>

<style scoped>
.login-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 80vh;
}
.login-card {
  background: white;
  padding: 30px;
  border: 1px solid #ddd;
  border-radius: 6px;
  width: 300px;
  box-shadow: 0 2px 6px rgba(0,0,0,0.1);
  text-align: center;
}
.login-card h1 {
  margin-bottom: 20px;
  color: #1976d2;
}
.login-card input {
  width: 100%;
  padding: 8px;
  margin: 8px 0;
  border: 1px solid #ccc;
  border-radius: 4px;
}
.login-card button {
  width: 100%;
  padding: 10px;
  background: #1976d2;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-top: 10px;
}
.login-card button:hover {
  background: #1565c0;
}
.error {
  color: red;
  margin-top: 10px;
}
</style>
