<script setup>
import { ref, onMounted } from 'vue'

const clientes = ref([])

onMounted(async () => {
  try {
    const res = await fetch('https://68d3e670214be68f8c67a728.mockapi.io/jacob')
    clientes.value = await res.json()
  } catch (err) {
    console.error('Error cargando clientes:', err)
  }
})
</script>

<template>
  <div>
    <h1>Clientes</h1>
    <ul>
      <li v-for="cliente in clientes" :key="cliente.id">
        <img :src="cliente.avatar" alt="foto cliente" width="50" height="50" />
        {{ cliente.name }} - {{ cliente.email }}
      </li>
    </ul>
  </div>
</template>
