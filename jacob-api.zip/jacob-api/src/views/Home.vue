<template>
  <h1>Bienvenido a la Página de Inicio</h1>
  <p>Usa el menú de arriba para navegar.</p>
</template>
